#' @title Numerical Gradient Calculation for Model Training Objective Function
#'
#' @description
#' This function computes the numerical gradient of the training objective function using finite difference approximation.
#' It employs parallel processing to efficiently calculate partial derivatives with respect to each model parameter,
#' supporting gradient-based optimization algorithms for model training.
#'
#' @param branch_params_vec See in ?f_train_cal.
#' @param h_max Numeric. Maximum step size for finite difference approximation. Default is 0.01.
#' @param h_min_percent Numeric. Minimum step size as a percentage of parameter range (between upper and lower bounds). Default is 0.01 (1%).
#' @param setseed See parameter set_seed in ?spilt_dataset.
#' @param ncores
#' See in ?get_interest_cell_type_data.
#' While this code can be executed on Windows systems, it is still strongly recommended to run it on Linux systems, as the execution time without parallel computing would be astronomically long.
#' The actual runtime depends on the total available RAM, the number of CPU cores, the previously determined number of cell groups, and the number of transcription factors (TFs) and target genes (TGs) obtained.
#' Larger core counts, fewer cell groups, and fewer genes correspond to shorter runtime, while the total available RAM dictates the maximum number of cores that can participate in parallel computing.
#'
#' @returns
#' A numeric vector representing the gradient of the objective function with respect to each parameter.
#' Using the finite difference method to approximate the gradient.
#'
#' @details
#' The function implements the following computational strategy:
#' \enumerate{
#' \item Step Size Determination: For each parameter, computes an adaptive step size that is the minimum of \code{h_max} and \code{h_min_percent} of the parameter's range (difference between upper and lower bounds)
#' \item Baseline Evaluation: Computes the objective function value at the current parameters
#' \item Parallel Gradient Calculation: Uses parallel processing to compute partial derivatives for each parameter by perturbing one parameter at a time
#' \item Robustness Handling: Replaces NA or infinite gradient values with 0 for numerical stability
#' }
#'
#' @note
#' Important considerations:
#' \itemize{
#' \item The function assumes the existence of global variables \code{branch_params_vec_upper} and \code{branch_params_vec_lower} that define parameter bounds for adaptive step sizing
#' \item Depends on \code{scDEDS::f_train_cal} for objective function evaluation
#' \item Uses forward difference approximation which has O(h) error
#' \item Parallel processing significantly speeds up computation for high-dimensional parameter spaces
#' \item Adaptive step sizing helps balance numerical precision and computational stability
#' \item NA and infinite values are replaced with 0, which may mask numerical issues but can ensure smooth program operation
#' }
#'
#' @seealso \code{\link{f_train_cal}}, \code{\link[parallel]{mclapply}}
#'
#' @export
#'
#' @examples
#' \dontrun{
#' branch_params_vec = numeric(0)
#' h_max = 0.01
#' h_min_percent = 0.01
#' setseed = 123 # Reproducible
#' # setseed = stats::runif(1) # Not Reproducible
#' ncores = ceiling(detectCores() / 2) # In Linux.
#' temp_grad = f_train_cal_gr(
#'   branch_params_vec = branch_params_vec,
#'   h_max = h_max,
#'   h_min_percent = h_min_percent,
#'   setseed = setseed,
#'   ncores = ncores)
#' }
f_train_cal_gr =  function(branch_params_vec = branch_params_vec,
                           h_max = 0.01,
                           h_min_percent = 0.01,
                           setseed = stats::runif(1),
                           ncores = 1)
{
  base::set.seed(setseed)
  vec = base::as.numeric(branch_params_vec)
  n = base::length(vec)
  f0 = scDEDS::f_train_cal(vec)
  h_vec = base::pmin(
    base::rep(h_max, n),
    (branch_params_vec_upper - branch_params_vec_lower) * h_min_percent
  ) # Set step length.
  grad = base::unlist(
    parallel::mclapply(
      1:n,
      function(i) { # Parallel computation of gradient components.
        par_perturb = vec
        par_perturb[i] = vec[i] + h_vec[i]  # Positive perturbation.
        gr = (scDEDS::f_train_cal(par_perturb) - f0) / h_vec[i]
        rm(list = base::setdiff(base::ls(), "gr"))
        return(gr)
      },
      mc.cores = ncores,
      mc.silent = TRUE,
      mc.allow.recursive = FALSE
    )
  )
  grad[base::is.na(grad) | base::is.infinite(grad)] = 0
  return(grad)
}
