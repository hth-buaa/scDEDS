utils::globalVariables(
  c(
    "%>%", "label", "tao", "Tslot_K", "branch_params_names", "train_data_pos",
    "branch_params_vec_upper", "branch_params_vec_lower", "results_identify_TGs",
    "TFs_in_JASPAR2024", "seurat_annotations", "BSgenome.Hsapiens.UCSC.hg38",
    "Potential_TFs", "match_score", "TxDb.Hsapiens.UCSC.hg38.knownGene",
    "ENSEMBL", "SYMBOL", "annotation", "result_gradient", "theta_s"
  )
)
